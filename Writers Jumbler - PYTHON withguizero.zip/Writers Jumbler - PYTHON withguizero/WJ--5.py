from guizero import App, Window, MenuBar, TextBox, Text, PushButton, Slider
import random
from operator import itemgetter
import os
from os import path
import io
import sys

def file_function():
    ("File option")
def edit_function():
    ("Edit Option")
def open_window_0():
    window0.show()
def close_window_0():
    window0.hide()
def open_window_1():
    window1.show()
def close_window_1():
    window1.hide()
def open_window_2():
    window2.show()
def close_window_2():
    window2.hide()

def open_window_4():
    window4.show()
def close_window_4():
    window4.hide()
def open_window_5():
    window5.show()
def close_window_5():
    window5.hide()
def open_window_6():
    window6.show()
def close_window_6():
    window6.hide()

app = App(title="Writers Jumbler - 5 Columns", bg="#d2d2d2", width=1890, height=350, layout="grid")

window5 = Window(app, title="WJ-Color Background", bg="#d2d2d2", width=320, height=340)
message2 = Text(window5, text="", size=12)

mna = ""
def Change1(mna):
    haaha = (Change1)

mnb = ""
def Change2(mnb):
    haahb = (Change2)

mnc = ""
def Change3(mnc):
    haahc = (Change3)
    
lbl0 = Text(window5, text="", size=2)
message7 = Text(window5, text="RED", size=12)
lbl0 = Text(window5, text="", size=2)
colorSlide1 = Slider(window5, command=Change1, start=0, end=255)
colorSlide1.bg = "#ffffff"
colorSlide1.width = "255"
colorSlide1.value = "255"
lbl0 = Text(window5, text="", size=2)
message8 = Text(window5, text="GREEN", size=12)
lbl0 = Text(window5, text="", size=2)
colorSlide2 = Slider(window5, command=Change2, start=0, end=255)
colorSlide2.bg = "#ffffff"
colorSlide2.width = "255"
colorSlide2.value = "255"
lbl0 = Text(window5, text="", size=2)
message9 = Text(window5, text="BLUE", size=12)
lbl0 = Text(window5, text="", size=2)
colorSlide3 = Slider(window5, command=Change3, start=0, end=255)
colorSlide3.bg = "#ffffff"
colorSlide3.width = "255"
colorSlide3.value = "255"

def colorRGB():
    colorRa = colorSlide1.value
    colorGa = colorSlide2.value
    colorBa = colorSlide3.value
    colorCT = (colorRa, colorGa, colorBa)
    window0.bg = colorCT

lbl0 = Text(window5, text="", size=2)
color_text = PushButton(window5, command=colorRGB, text="Color This Window Background")
color_text.bg = "#c0c0ff"
color_text.text_color = "#000000"

close_window_5()

window6 = Window(app, title="WJ-Color Font", bg="#d2d2d2", width=320, height=340)

message2 = Text(window6, text="", size=12)

mna = ""
def Change4(mna):
    haaha = (Change4)

mnb = ""
def Change5(mnb):
    haahb = (Change5)

mnc = ""
def Change6(mnc):
    haahc = (Change6)

lbl0 = Text(window6, text="", size=2)
message10 = Text(window6, text="RED", size=12)
lbl0 = Text(window6, text="", size=2)
colorSlide4 = Slider(window6, command=Change4, start=0, end=255)
colorSlide4.bg = "#ffffff"
colorSlide4.width = "255"
colorSlide4.value = "0"
lbl0 = Text(window6, text="", size=2)
message11 = Text(window6, text="GREEN", size=12)
lbl0 = Text(window6, text="", size=2)
colorSlide5 = Slider(window6, command=Change5, start=0, end=255)
colorSlide5.bg = "#ffffff"
colorSlide5.width = "255"
colorSlide5.value = "0"
lbl0 = Text(window6, text="", size=2)
message12 = Text(window6, text="BLUE", size=12)
lbl0 = Text(window6, text="", size=2)
colorSlide6 = Slider(window6, command=Change6, start=0, end=255)
colorSlide6.bg = "#ffffff"
colorSlide6.width = "255"
colorSlide6.value = "0"

def colorCFT():
    colorRf2 = colorSlide4.value
    colorGf2 = colorSlide5.value
    colorBf2 = colorSlide6.value
    colorCTf = (colorRf2, colorGf2, colorBf2)
    window0.text_color = colorCTf

message2 = Text(window6, text="", size=8)
color_text = PushButton(window6, command=colorCFT, text="Color Fonts")
color_text.bg = "#c0c0ff"
color_text.text_color = "#000000"
close_window_6()


def savas5():

    aValue = text1.value
    bValue = text2.value
    cValue = text3.value
    dValue = text4.value
    eValue = text5.value
    fValue = text6.value
    gValue = text7.value
    hValue = text8.value
    iValue = text9.value
    jValue = text10.value
    kValue = text11.value
    lValue = text12.value
    mValue = text13.value
    nValue = text14.value
    oValue = text15.value
    pValue = text16.value
    qValue = text17.value
    rValue = text18.value
    sValue = text19.value
    tValue = text20.value
    uValue = text21.value
    vValue = text22.value
    wValue = text23.value
    xValue = text24.value
    yValue = text25.value
    zValue = text26.value
    aaValue = text27.value
    abValue = text28.value
    acValue = text29.value
    adValue = text30.value
    aeValue = text31.value
    afValue = text32.value
    agValue = text33.value
    ahValue = text34.value
    aiValue = text35.value
    ajValue = text36.value
    akValue = text37.value
    alValue = text38.value
    amValue = text39.value
    anValue = text40.value
    aoValue = text41.value
    apValue = text42.value
    aqValue = text43.value
    arValue = text44.value
    asValue = text45.value
    atValue = text46.value
    auValue = text47.value
    avValue = text48.value
    awValue = text49.value
    axValue = text50.value

    word = "WJ5_inOrder_5c_"
    i = random.randint(0, 1000000)
    z = word + str(i) + ".csv"

    file = open(z, "w")

    allMessages = str(aValue) +  "," +  str(bValue) +  "," +  str(cValue) +  "," +  str(dValue) +  "," +  str(eValue) +  "," +  str(fValue) +  "," +  str(gValue) +  "," +  str(hValue) +  "," +  str(iValue) +  "," +  str(jValue) +  "," +  str(kValue) +  "," +  str(lValue) +  "," + str(mValue) +  "," +  str(nValue) +  "," +  str(oValue) +  "," +  str(pValue) +  "," +  str(qValue) +  "," +  str(rValue) +  "," +  str(sValue) +  "," +  str(tValue) +  "," +  str(uValue) +  "," +  str(vValue) +  "," +  str(wValue) +  "," +  str(xValue) +  "," +  str(yValue) +  "," +  str(zValue) +  "," +  str(aaValue) +  "," +  str(abValue) +  "," +  str(acValue) +  "," +  str(adValue) +  "," +  str(aeValue) +  "," +  str(afValue) +  "," +  str(agValue) +  "," +  str(ahValue) +  "," +  str(aiValue) +  "," +  str(ajValue) +  "," +  str(akValue) +  "," +  str(alValue) +  "," +  str(amValue) +  "," +  str(anValue) +  "," +  str(aoValue) +  "," +  str(apValue) +  "," +  str(aqValue) +  "," +  str(arValue) +  "," +  str(asValue) +  "," +  str(atValue) +  "," +  str(auValue) +  "," +  str(avValue) +  "," +  str(awValue) +  "," +  str(axValue)
    file.write(allMessages)
    file.close()

def getfiles7():
    list_a = []
    list_b = []
    list_c = []
    list_d = []
    list_e = []
    list_f = []
    list_g = []
    list_h = []
    list_i = []
    list_j = []
    list_k = []
    list_l = []
    list_m = []
    list_n = []
    list_o = []
    list_p = []
    list_q = []
    list_r = []
    list_s = []
    list_t = []
    list_u = []
    list_v = []
    list_w = []
    list_x = []
    list_y = []
    list_z = []
    list_aa = []
    list_ab = []
    list_ac = []
    list_ad = []
    list_ae = []
    list_af = []
    list_ag = []
    list_ah = []
    list_ai = []
    list_aj = []
    list_ak = []
    list_al = []
    list_am = []
    list_an = []
    list_ao = []
    list_ap = []
    list_aq = []
    list_ar = []
    list_as = []
    list_at = []
    list_au = []
    list_av = []
    list_aw = []
    list_ax = []
    ab = text1d1.value
    with open(ab, "r") as t:
        for line in t:
            words = line.split(",")
            word_1 = words[0]
            word_2 = words[1]
            word_3 = words[2]
            word_4 = words[3]
            word_5 = words[4]
            word_6 = words[5]
            word_7 = words[6]
            word_8 = words[7]
            word_9 = words[8]
            word_10 = words[9]
            word_11 = words[10]
            word_12 = words[11]
            word_13 = words[12]
            word_14 = words[13]
            word_15 = words[14]
            word_16 = words[15]
            word_17 = words[16]
            word_18 = words[17]
            word_19 = words[18]
            word_20 = words[19]
            word_21 = words[20]
            word_22 = words[21]
            word_23 = words[22]
            word_24 = words[23]
            word_25 = words[24]
            word_26 = words[25]
            word_27 = words[26]
            word_28 = words[27]
            word_29 = words[28]
            word_30 = words[29]
            word_31 = words[30]
            word_32 = words[31]
            word_33 = words[32]
            word_34 = words[33]
            word_35 = words[34]
            word_36 = words[35]
            word_37 = words[36]
            word_38 = words[37]
            word_39 = words[38]
            word_40 = words[39]
            word_41 = words[40]
            word_42 = words[41]
            word_43 = words[42]
            word_44 = words[43]
            word_45 = words[44]
            word_46 = words[45]
            word_47 = words[46]
            word_48 = words[47]
            word_49 = words[48]
            word_50 = words[49]
            text1.value = word_1
            text2.value = word_2
            text3.value = word_3
            text4.value = word_4
            text5.value = word_5
            text6.value = word_6
            text7.value = word_7
            text8.value = word_8
            text9.value = word_9
            text10.value = word_10
            text11.value = word_11
            text12.value = word_12
            text13.value = word_13
            text14.value = word_14
            text15.value = word_15
            text16.value = word_16
            text17.value = word_17
            text18.value = word_18
            text19.value = word_19
            text20.value = word_20
            text21.value = word_21
            text22.value = word_22
            text23.value = word_23
            text24.value = word_24
            text25.value = word_25
            text26.value = word_26
            text27.value = word_27
            text28.value = word_28
            text29.value = word_29
            text30.value = word_30
            text31.value = word_31
            text32.value = word_32
            text33.value = word_33
            text34.value = word_34
            text35.value = word_35
            text36.value = word_36
            text37.value = word_37
            text38.value = word_38
            text39.value = word_39
            text40.value = word_40
            text41.value = word_41
            text42.value = word_42
            text43.value = word_43
            text44.value = word_44
            text45.value = word_45
            text46.value = word_46
            text47.value = word_47
            text48.value = word_48
            text49.value = word_49
            text50.value = word_50
    list_a = []
    list_b = []
    list_c = []
    list_d = []
    list_e = []
    list_f = []
    list_g = []
    list_h = []
    list_i = []
    list_j = []
    list_k = []
    list_l = []
    list_m = []
    list_n = []
    list_o = []
    list_p = []
    list_q = []
    list_r = []
    list_s = []
    list_t = []
    list_u = []
    list_v = []
    list_w = []
    list_x = []
    list_y = []
    list_z = []
    list_aa = []
    list_ab = []
    list_ac = []
    list_ad = []
    list_ae = []
    list_af = []
    list_ag = []
    list_ah = []
    list_ai = []
    list_aj = []
    list_ak = []
    list_al = []
    list_am = []
    list_an = []
    list_ao = []
    list_ap = []
    list_aq = []
    list_ar = []
    list_as = []
    list_at = []
    list_au = []
    list_av = []
    list_aw = []
    list_ax = []
    ab = text1d1.value
    with open(ab, "r") as s:
        for line in s:
            words = line.split(",")
            list_a.append(words[0])
            list_b.append(words[1])
            list_c.append(words[2])
            list_d.append(words[3])
            list_e.append(words[4])
            list_f.append(words[5])
            list_g.append(words[6])
            list_h.append(words[7])
            list_i.append(words[8])
            list_j.append(words[9])
            list_k.append(words[10])
            list_l.append(words[11])
            list_m.append(words[12])
            list_n.append(words[13])
            list_o.append(words[14])
            list_p.append(words[15])
            list_q.append(words[16])
            list_r.append(words[17])
            list_s.append(words[18])
            list_t.append(words[19])
            list_u.append(words[20])
            list_v.append(words[21])
            list_w.append(words[22])
            list_x.append(words[23])
            list_y.append(words[24])
            list_z.append(words[25])
            list_aa.append(words[26])
            list_ab.append(words[27])
            list_ac.append(words[28])
            list_ad.append(words[29])
            list_ae.append(words[30])
            list_af.append(words[31])
            list_ag.append(words[32])
            list_ah.append(words[33])
            list_ai.append(words[34])
            list_aj.append(words[35])
            list_ak.append(words[36])
            list_al.append(words[37])
            list_am.append(words[38])
            list_an.append(words[39])
            list_ao.append(words[40])
            list_ap.append(words[41])
            list_aq.append(words[42])
            list_ar.append(words[43])
            list_as.append(words[44])
            list_at.append(words[45])
            list_au.append(words[46])
            list_av.append(words[47])
            list_aw.append(words[48])
            list_ax.append(words[49])

    xa = list_a
    xb = list_b
    xc = list_c
    xd = list_d
    xe = list_e
    xf = list_f
    xg = list_g
    xh = list_h
    xi = list_i
    xj = list_j
    xk = list_k
    xl = list_l
    xm = list_m
    xn = list_n
    xo = list_o
    xp = list_p
    xq = list_q
    xr = list_r
    xs = list_s
    xt = list_t
    xu = list_u
    xv = list_v
    xw = list_w
    xx = list_x
    xy = list_y
    xz = list_z
    xaa = list_aa
    xab = list_ab
    xac = list_ac
    xad = list_ad
    xae = list_ae
    xaf = list_af
    xag = list_ag
    xah = list_ah
    xai = list_ai
    xaj = list_aj
    xak = list_ak
    xal = list_al
    xam = list_am
    xan = list_an
    xao = list_ao
    xap = list_ap
    xaq = list_aq
    xar = list_ar
    xas = list_as
    xat = list_at
    xau = list_au
    xav = list_av
    xaw = list_aw
    xax = list_ax

    ka = [xa]
    kb = [xb]
    kc = [xc]
    kd = [xd]
    ke = [xe]
    kf = [xf]
    kg = [xg]
    kh = [xh]
    ki = [xi]
    kj = [xj]
    kk = [xk]
    kl = [xl]
    km = [xm]
    kn = [xn]
    ko = [xo]
    kp = [xp]
    kq = [xq]
    kr = [xr]
    ks = [xs]
    kt = [xt]
    ku = [xu]
    kv = [xv]
    kw = [xw]
    kx = [xx]
    ky = [xy]
    kz = [xz]
    kaa = [xaa]
    kab = [xab]
    kac = [xac]
    kad = [xad]
    kae = [xae]
    kaf = [xaf]
    kag = [xag]
    kah = [xah]
    kai = [xai]
    kaj = [xaj]
    kak = [xak]
    kal = [xal]
    kam = [xam]
    kan = [xan]
    kao = [xao]
    kap = [xap]
    kaq = [xaq]
    kar = [xar]
    kas = [xas]
    kat = [xat]
    kau = [xau]
    kav = [xav]
    kaw = [xaw]
    kax = [xax]

    xxxxx1 = (ka, kb, kc, kd, ke, kf, kg, kh, ki, kj)

    xxxx1x = "".join(repr(xxxxx1).replace(",", "\n").replace("(", "").replace(")", "").replace("[", "").replace("]", ""))

    message1Also.value = xxxx1x
    
    xxxxx2 = (kk, kl, km, kn, ko, kp, kq, kr, ks, kt)

    xxxx2x = "".join(repr(xxxxx2).replace(",", "\n").replace("(", "").replace(")", "").replace("[", "").replace("]", ""))

    message2Also.value = xxxx2x

    xxxxx3 = (ku, kv, kw, kx, ky, kz, kaa, kab, kac, kad)

    xxxx3x = "".join(repr(xxxxx3).replace(",", "\n").replace("(", "").replace(")", "").replace("[", "").replace("]", ""))

    message3Also.value = xxxx3x

    xxxxx4 = (kae, kaf, kag, kah, kai, kaj, kak, kal, kam, kan)

    xxxx4x = "".join(repr(xxxxx4).replace(",", "\n").replace("(", "").replace(")", "").replace("[", "").replace("]", ""))

    message4Also.value = xxxx4x

    xxxxx5 = (kao, kap, kaq, kar, kas, kat, kau, kav, kaw, kax)

    xxxx5x = "".join(repr(xxxxx5).replace(",", "\n").replace("(", "").replace(")", "").replace("[", "").replace("]", ""))

    message5Also.value = xxxx5x


def getfiles5():
    files = []
    files = os.listdir(os.getcwd())
    files = "".join(repr(files).replace(",", "\n")).replace("[", "").replace("]", "").replace("'", "")
    message4.value = files

exitWindow = exit

file_Menu = MenuBar(app, toplevel=["File", "Options"], options=[ [ ["Save, with Random File Name", savas5], ["Open Directory Box", open_window_2], ["Open Directory Window", open_window_1], ["List Files In WJ-Directory", getfiles5], ["Fill, From File", getfiles7], ["Exit, Writers Jumbler", exitWindow] ], [ ["Open Rearrangements", open_window_0], ["Open Color Background", open_window_5], ["Open Color Font", open_window_6], ["Open Action Buttons", open_window_4]],])

message = Text(app, text="", size=18, grid=[0,1])
text1 = TextBox(app, width=32, height=16, grid=[0,2])
text1.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,3])
text2 = TextBox(app, width=32, height=16, grid=[0,4])
text2.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,5])
text3 = TextBox(app, width=32, height=16, grid=[0,6])
text3.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,7])
text4 = TextBox(app, width=32, height=16, grid=[0,8])
text4.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,9])
text5 = TextBox(app, width=32, height=16, grid=[0,10])
text5.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,11])
text6 = TextBox(app, width=32, height=16, grid=[0,12])
text6.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,13])
text7 = TextBox(app, width=32, height=16, grid=[0,14])
text7.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,15])
text8 = TextBox(app, width=32, height=16, grid=[0,16])
text8.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,17])
text9 = TextBox(app, width=32, height=16, grid=[0,18])
text9.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,19])
text10 = TextBox(app, width=32, height=16, grid=[0,20])
text10.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[0,21])

text11 = TextBox(app, width=32, height=16, grid=[1,2])
text11.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,3])
text12 = TextBox(app, width=32, height=16, grid=[1,4])
text12.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,5])
text13 = TextBox(app, width=32, height=16, grid=[1,6])
text13.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,7])
text14 = TextBox(app, width=32, height=16, grid=[1,8])
text14.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,9])
text15 = TextBox(app, width=32, height=16, grid=[1,10])
text15.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,11])
text16 = TextBox(app, width=32, height=16, grid=[1,12])
text16.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,13])
text17 = TextBox(app, width=32, height=16, grid=[1,14])
text17.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,15])
text18 = TextBox(app, width=32, height=16, grid=[1,16])
text18.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,17])
text19 = TextBox(app, width=32, height=16, grid=[1,18])
text19.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,19])
text20 = TextBox(app, width=32, height=16, grid=[1,20])
text20.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[1,21])

text21 = TextBox(app, width=32, height=16, grid=[2,2])
text21.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[2,3])
text22 = TextBox(app, width=32, height=16, grid=[2,4])
text22.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[2,5])
text23 = TextBox(app, width=32, height=16, grid=[2,6])
text23.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[2,7])
text24 = TextBox(app, width=32, height=16, grid=[2,8])
text24.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[2,9])
text25 = TextBox(app, width=32, height=16, grid=[2,10])
text25.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[2,11])
text26 = TextBox(app, width=32, height=16, grid=[2,12])
text26.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[2,13])
text27 = TextBox(app, width=32, height=16, grid=[2,14])
text27.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[2,15])
text28 = TextBox(app, width=32, height=16, grid=[2,16])
text28.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[2,17])
text29 = TextBox(app, width=32, height=16, grid=[2,18])
text29.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[2,19])
text30 = TextBox(app, width=32, height=16, grid=[2,20])
text30.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[2,21])

text31 = TextBox(app, width=32, height=16, grid=[3,2])
text31.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[3,3])
text32 = TextBox(app, width=32, height=16, grid=[3,4])
text32.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[3,5])
text33 = TextBox(app, width=32, height=16, grid=[3,6])
text33.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[3,7])
text34 = TextBox(app, width=32, height=16, grid=[3,8])
text34.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[3,9])
text35 = TextBox(app, width=32, height=16, grid=[3,10])
text35.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[3,11])
text36 = TextBox(app, width=32, height=16, grid=[3,12])
text36.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[3,13])
text37 = TextBox(app, width=32, height=16, grid=[3,14])
text37.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[3,15])
text38 = TextBox(app, width=32, height=16, grid=[3,16])
text38.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[3,17])
text39 = TextBox(app, width=32, height=16, grid=[3,18])
text39.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[3,19])
text40 = TextBox(app, width=32, height=16, grid=[3,20])
text40.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[3,21])

text41 = TextBox(app, width=32, height=16, grid=[4,2])
text41.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[4,3])
text42 = TextBox(app, width=32, height=16, grid=[4,4])
text42.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[4,5])
text43 = TextBox(app, width=32, height=16, grid=[4,6])
text43.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[4,7])
text44 = TextBox(app, width=32, height=16, grid=[4,8])
text44.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[4,9])
text45 = TextBox(app, width=32, height=16, grid=[4,10])
text45.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[4,11])
text46 = TextBox(app, width=32, height=16, grid=[4,12])
text46.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[4,13])
text47 = TextBox(app, width=32, height=16, grid=[4,14])
text47.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[4,15])
text48 = TextBox(app, width=32, height=16, grid=[4,16])
text48.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[4,17])
text49 = TextBox(app, width=32, height=16, grid=[4,18])
text49.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[4,19])
text50 = TextBox(app, width=32, height=16, grid=[4,20])
text50.bg = "#ffffff"
message2 = Text(app, text=" ", size=2, grid=[4,21])

def messages():
    value1 = str(random.randint(0, 9))
    value2 = str(random.randint(0, 9))
    value3 = str(random.randint(0, 9))
    value4 = str(random.randint(0, 9))
    value5 = str(random.randint(0, 9))
    value6 = str(random.randint(0, 9))
    value7 = str(random.randint(0, 9))
    value8 = str(random.randint(0, 9))
    value9 = str(random.randint(0, 9))
    value10 = str(random.randint(0, 9))

    aValue = text1.value
    bValue = text2.value
    cValue = text3.value
    dValue = text4.value
    eValue = text5.value
    fValue = text6.value
    gValue = text7.value
    hValue = text8.value
    iValue = text9.value
    jValue = text10.value

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]

    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    ka = [xa]
    kb = [xb]
    kc = [xc]
    kd = [xd]
    ke = [xe]
    kf = [xf]
    kg = [xg]
    kh = [xh]
    ki = [xi]
    kj = [xj]

    xxxx = (ka, kb, kc, kd, ke, kf, kg, kh, ki, kj)

    xxxxx0 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message1.value = xxxxx0
    
def messagesC2():
    value1 = str(random.randint(0, 9))
    value2 = str(random.randint(0, 9))
    value3 = str(random.randint(0, 9))
    value4 = str(random.randint(0, 9))
    value5 = str(random.randint(0, 9))
    value6 = str(random.randint(0, 9))
    value7 = str(random.randint(0, 9))
    value8 = str(random.randint(0, 9))
    value9 = str(random.randint(0, 9))
    value10 = str(random.randint(0, 9))

    aValue = text11.value
    bValue = text12.value
    cValue = text13.value
    dValue = text14.value
    eValue = text15.value
    fValue = text16.value
    gValue = text17.value
    hValue = text18.value
    iValue = text19.value
    jValue = text20.value

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]

    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    ka = [xa]
    kb = [xb]
    kc = [xc]
    kd = [xd]
    ke = [xe]
    kf = [xf]
    kg = [xg]
    kh = [xh]
    ki = [xi]
    kj = [xj]

    xxxx = (ka, kb, kc, kd, ke, kf, kg, kh, ki, kj)

    xxxxx0 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message2C.value = xxxxx0

def messagesC3():
    value1 = str(random.randint(0, 9))
    value2 = str(random.randint(0, 9))
    value3 = str(random.randint(0, 9))
    value4 = str(random.randint(0, 9))
    value5 = str(random.randint(0, 9))
    value6 = str(random.randint(0, 9))
    value7 = str(random.randint(0, 9))
    value8 = str(random.randint(0, 9))
    value9 = str(random.randint(0, 9))
    value10 = str(random.randint(0, 9))

    aValue = text21.value
    bValue = text22.value
    cValue = text23.value
    dValue = text24.value
    eValue = text25.value
    fValue = text26.value
    gValue = text27.value
    hValue = text28.value
    iValue = text29.value
    jValue = text30.value

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]

    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    ka = [xa]
    kb = [xb]
    kc = [xc]
    kd = [xd]
    ke = [xe]
    kf = [xf]
    kg = [xg]
    kh = [xh]
    ki = [xi]
    kj = [xj]

    xxxx = (ka, kb, kc, kd, ke, kf, kg, kh, ki, kj)

    xxxxx0 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message3C.value = xxxxx0

def messagesC4():
    value1 = str(random.randint(0, 9))
    value2 = str(random.randint(0, 9))
    value3 = str(random.randint(0, 9))
    value4 = str(random.randint(0, 9))
    value5 = str(random.randint(0, 9))
    value6 = str(random.randint(0, 9))
    value7 = str(random.randint(0, 9))
    value8 = str(random.randint(0, 9))
    value9 = str(random.randint(0, 9))
    value10 = str(random.randint(0, 9))

    aValue = text21.value
    bValue = text22.value
    cValue = text23.value
    dValue = text24.value
    eValue = text25.value
    fValue = text26.value
    gValue = text27.value
    hValue = text28.value
    iValue = text29.value
    jValue = text30.value

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]

    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    ka = [xa]
    kb = [xb]
    kc = [xc]
    kd = [xd]
    ke = [xe]
    kf = [xf]
    kg = [xg]
    kh = [xh]
    ki = [xi]
    kj = [xj]

    xxxx = (ka, kb, kc, kd, ke, kf, kg, kh, ki, kj)

    xxxxx0 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message4C.value = xxxxx0

def messagesC5():
    value1 = str(random.randint(0, 9))
    value2 = str(random.randint(0, 9))
    value3 = str(random.randint(0, 9))
    value4 = str(random.randint(0, 9))
    value5 = str(random.randint(0, 9))
    value6 = str(random.randint(0, 9))
    value7 = str(random.randint(0, 9))
    value8 = str(random.randint(0, 9))
    value9 = str(random.randint(0, 9))
    value10 = str(random.randint(0, 9))

    aValue = text31.value
    bValue = text32.value
    cValue = text33.value
    dValue = text34.value
    eValue = text35.value
    fValue = text36.value
    gValue = text37.value
    hValue = text38.value
    iValue = text39.value
    jValue = text40.value

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]

    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    ka = [xa]
    kb = [xb]
    kc = [xc]
    kd = [xd]
    ke = [xe]
    kf = [xf]
    kg = [xg]
    kh = [xh]
    ki = [xi]
    kj = [xj]

    xxxx = (ka, kb, kc, kd, ke, kf, kg, kh, ki, kj)

    xxxxx0 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message5C.value = xxxxx0

def messagesCa():
    value1 = str(random.randint(0, 9))
    value2 = str(random.randint(0, 9))
    value3 = str(random.randint(0, 9))
    value4 = str(random.randint(0, 9))
    value5 = str(random.randint(0, 9))
    value6 = str(random.randint(0, 9))
    value7 = str(random.randint(0, 9))
    value8 = str(random.randint(0, 9))
    value9 = str(random.randint(0, 9))
    value10 = str(random.randint(0, 9))

    aValue = text1.value
    bValue = text2.value
    cValue = text3.value
    dValue = text4.value
    eValue = text5.value
    fValue = text6.value
    gValue = text7.value
    hValue = text8.value
    iValue = text9.value
    jValue = text10.value

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]

    zzx1 = sorted(ya, key=itemgetter(0), reverse=False)
    zzz1 = zzx1

    qa = zzx1[0]
    qb = zzx1[1]
    qc = zzx1[2]
    qd = zzx1[3]
    qe = zzx1[4]
    qf = zzx1[5]
    qg = zzx1[6]
    qh = zzx1[7]
    qi = zzx1[8]
    qj = zzx1[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    ka = [xa]
    kb = [xb]
    kc = [xc]
    kd = [xd]
    ke = [xe]
    kf = [xf]
    kg = [xg]
    kh = [xh]
    ki = [xi]
    kj = [xj]

    xxxx0 = (ka, kb, kc, kd, ke, kf, kg, kh, ki, kj)

    xxxxx0 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message1.value = xxxxx0

    value11 = str(random.randint(0, 9))
    value12 = str(random.randint(0, 9))
    value13 = str(random.randint(0, 9))
    value14 = str(random.randint(0, 9))
    value15 = str(random.randint(0, 9))
    value16 = str(random.randint(0, 9))
    value17 = str(random.randint(0, 9))
    value18 = str(random.randint(0, 9))
    value19 = str(random.randint(0, 9))
    value20 = str(random.randint(0, 9))

    kValue = text11.value
    lValue = text12.value
    mValue = text13.value
    nValue = text14.value
    oValue = text15.value
    pValue = text16.value
    qValue = text17.value
    rValue = text18.value
    sValue = text19.value
    tValue = text20.value

    zk = []
    zl = []
    zm = []
    zn = []
    zo = []
    zp = []
    zq = []
    zr = []
    zs = []
    zt = []

    ya = [zk, zl, zm, zn, zo, zp, zq, zr, zs, zt]
    zk = [value11, kValue, '\n']
    zl = [value12, lValue, '\n']
    zm = [value13, mValue, '\n']
    zn = [value14, nValue, '\n']
    zo = [value15, oValue, '\n']
    zp = [value16, pValue, '\n']
    zq = [value17, qValue, '\n']
    zr = [value18, rValue, '\n']
    zs = [value19, sValue, '\n']
    zt = [value20, tValue, '\n']
    ya = [zk, zl, zm, zn, zo, zp, zq, zr, zs, zt]

    zzx2 = sorted(ya, key=itemgetter(0), reverse=False)
    zzz2 = zzx2

    qk = zzx2[0]
    ql = zzx2[1]
    qm = zzx2[2]
    qn = zzx2[3]
    qo = zzx2[4]
    qp = zzx2[5]
    qq = zzx2[6]
    qr = zzx2[7]
    qs = zzx2[8]
    qt = zzx2[9]

    xk = qk[-2]
    xl = ql[-2]
    xm = qm[-2]
    xn = qn[-2]
    xo = qo[-2]
    xp = qp[-2]
    xq = qq[-2]
    xr = qr[-2]
    xs = qs[-2]
    xt = qt[-2]

    kk = [xk]
    kl = [xl]
    km = [xm]
    kn = [xn]
    ko = [xo]
    kp = [xp]
    kq = [xq]
    kr = [xr]
    ks = [xs]
    kt = [xt]

    xxxx1 = (kk, kl, km, kn, ko, kp, kq, kr, ks, kt)

    xxxxx1 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message2C.value = xxxxx1

    value21 = str(random.randint(0, 9))
    value22 = str(random.randint(0, 9))
    value23 = str(random.randint(0, 9))
    value24 = str(random.randint(0, 9))
    value25 = str(random.randint(0, 9))
    value26 = str(random.randint(0, 9))
    value27 = str(random.randint(0, 9))
    value28 = str(random.randint(0, 9))
    value29 = str(random.randint(0, 9))
    value30 = str(random.randint(0, 9))

    uValue = text21.value
    vValue = text22.value
    wValue = text23.value
    xValue = text24.value
    yValue = text25.value
    zValue = text26.value
    aaValue = text27.value
    abValue = text28.value
    acValue = text29.value
    adValue = text30.value

    zu = []
    zv = []
    zw = []
    zx = []
    zy = []
    zz = []
    zaa = []
    zab = []
    zac = []
    zad = []

    ya = [zu, zv, zw, zx, zy, zz, zaa, zab, zac, zad]
    zu = [value21, uValue, '\n']
    zv = [value22, vValue, '\n']
    zw = [value23, wValue, '\n']
    zx = [value24, xValue, '\n']
    zy = [value25, yValue, '\n']
    zz = [value26, zValue, '\n']
    zaa = [value27, aaValue, '\n']
    zab = [value28, abValue, '\n']
    zac = [value29, acValue, '\n']
    zad = [value30, adValue, '\n']
    ya = [zu, zv, zw, zx, zy, zz, zaa, zab, zac, zad]

    zzx3 = sorted(ya, key=itemgetter(0), reverse=False)
    zzz3 = zzx3

    qu = zzx3[0]
    qv = zzx3[1]
    qw = zzx3[2]
    qx = zzx3[3]
    qy = zzx3[4]
    qz = zzx3[5]
    qaa = zzx3[6]
    qab = zzx3[7]
    qac = zzx3[8]
    qad = zzx3[9]

    xu = qu[-2]
    xv = qv[-2]
    xw = qw[-2]
    xx = qx[-2]
    xy = qy[-2]
    xz = qz[-2]
    xaa = qaa[-2]
    xab = qab[-2]
    xac = qac[-2]
    xad = qad[-2]

    ku = [xu]
    kv = [xv]
    kw = [xw]
    kx = [xx]
    ky = [xy]
    kz = [xz]
    kaa = [xaa]
    kab = [xab]
    kac = [xac]
    kad = [xad]

    xxxx2 = (ku, kv, kw, kx, ky, kz, kaa, kab, kac, kad)

    xxxxx2 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message3C.value = xxxxx2

    value31 = str(random.randint(0, 9))
    value32 = str(random.randint(0, 9))
    value33 = str(random.randint(0, 9))
    value34 = str(random.randint(0, 9))
    value35 = str(random.randint(0, 9))
    value36 = str(random.randint(0, 9))
    value37 = str(random.randint(0, 9))
    value38 = str(random.randint(0, 9))
    value39 = str(random.randint(0, 9))
    value40 = str(random.randint(0, 9))

    aeValue = text21.value
    afValue = text22.value
    agValue = text23.value
    ahValue = text24.value
    aiValue = text25.value
    ajValue = text26.value
    akValue = text27.value
    alValue = text28.value
    amValue = text29.value
    anValue = text30.value

    zae = []
    zaf = []
    zag = []
    zah = []
    zai = []
    zaj = []
    zak = []
    zal = []
    zam = []
    zan = []

    ya = [zae, zaf, zag, zah, zai, zaj, zak, zal, zam, zan]
    zae = [value31, aeValue, '\n']
    zaf = [value32, afValue, '\n']
    zag = [value33, agValue, '\n']
    zah = [value34, ahValue, '\n']
    zaj = [value35, aiValue, '\n']
    zak = [value36, ajValue, '\n']
    zam = [value37, akValue, '\n']
    zan = [value38, alValue, '\n']
    zao = [value39, amValue, '\n']
    zap = [value40, anValue, '\n']
    ya = [zae, zaf, zag, zah, zai, zaj, zak, zal, zam, zan]

    zzx4 = sorted(ya, key=itemgetter(0), reverse=False)
    zzz4 = zzx4

    qae = zzx4[0]
    qaf = zzx4[1]
    qag = zzx4[2]
    qah = zzx4[3]
    qai = zzx4[4]
    qaj = zzx4[5]
    qak = zzx4[6]
    qal = zzx4[7]
    qam = zzx4[8]
    qan = zzx4[9]

    xae = qae[-2]
    xaf = qaf[-2]
    xag = qag[-2]
    xah = qah[-2]
    xai = qai[-2]
    xaj = qaj[-2]
    xak = qak[-2]
    xal = qal[-2]
    xam = qam[-2]
    xan = qan[-2]

    kae = [xae]
    kaf = [xaf]
    kag = [xag]
    kah = [xah]
    kai = [xai]
    kaj = [xaj]
    kak = [xak]
    kal = [xal]
    kam = [xam]
    kan = [xan]

    xxxx3 = (kae, kaf, kag, kah, kai, kaj, kak, kal, kam, kan)

    xxxxx3 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message4C.value = xxxxx3

    value41 = str(random.randint(0, 9))
    value42 = str(random.randint(0, 9))
    value43 = str(random.randint(0, 9))
    value44 = str(random.randint(0, 9))
    value45 = str(random.randint(0, 9))
    value46 = str(random.randint(0, 9))
    value47 = str(random.randint(0, 9))
    value48 = str(random.randint(0, 9))
    value49 = str(random.randint(0, 9))
    value50 = str(random.randint(0, 9))

    aoValue = text31.value
    apValue = text32.value
    aqValue = text33.value
    arValue = text34.value
    asValue = text35.value
    atValue = text36.value
    auValue = text37.value
    avValue = text38.value
    awValue = text39.value
    axValue = text40.value

    zao = []
    zap = []
    zaq = []
    zar = []
    zas = []
    zat = []
    zau = []
    zav = []
    zaw = []
    zax = []

    ya = [zao, zap, zaq, zar, zas, zat, zau, zav, zaw, zax]
    zao = [value41, aoValue, '\n']
    zap = [value42, apValue, '\n']
    zaq = [value43, aqValue, '\n']
    zar = [value44, arValue, '\n']
    zas = [value45, asValue, '\n']
    zat = [value46, atValue, '\n']
    zau = [value47, auValue, '\n']
    zav = [value48, avValue, '\n']
    zaw = [value49, awValue, '\n']
    zax = [value50, axValue, '\n']
    ya = [zao, zap, zaq, zar, zas, zat, zau, zav, zaw, zax]

    zzx5 = sorted(ya, key=itemgetter(0), reverse=False)
    zzz5 = zzx5

    qao = zzx5[0]
    qap = zzx5[1]
    qaq = zzx5[2]
    qar = zzx5[3]
    qas = zzx5[4]
    qat = zzx5[5]
    qau = zzx5[6]
    qav = zzx5[7]
    qaw = zzx5[8]
    qax = zzx5[9]

    xao = qao[-2]
    xap = qap[-2]
    xaq = qaq[-2]
    xar = qar[-2]
    xas = qas[-2]
    xat = qat[-2]
    xau = qau[-2]
    xav = qav[-2]
    xaw = qaw[-2]
    xax = qax[-2]

    kao = [xao]
    kap = [xap]
    kaq = [xaq]
    kar = [xar]
    kas = [xas]
    kat = [xat]
    kau = [xau]
    kav = [xav]
    kaw = [xaw]
    kax = [xax]

    xxxx5 = (kao, kap, kaq, kar, kas, kat, kau, kav, kaw, kax)

    xxxxx4 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message5C.value = xxxxx4
	
    word = "WJ5_Jumble_Save_5c_"
    i = random.randint(0, 1000000)
    z = word + str(i) + ".csv"

    file = open(z, "w")

    allMessages = str(ka) + "," + str(kb) + "," + str(kc) + "," + str(kd) + "," + str(ke) + "," + str(kf) + "," + str(kg) + "," + str(kh) + "," + str(ki) + "," + str(kj) + "," + str(kk) + "," + str(kl) + "," + str(km) + "," + str(kn) + "," + str(ko) + "," + str(kp) + "," + str(kq) + "," + str(kr) + "," +  str(ks) + "," + str(kt) + "," + str(ku) + "," + str(kv) + "," + str(kw) + "," + str(kx) + "," + str(ky) + "," + str(kz) + "," + str(kaa) + "," + str(kab) + "," + str(kac) + "," + str(kad) + "," + str(kae) + "," + str(kaf) + "," + str(kag) + "," + str(kah) + "," + str(kai) + "," + str(kaj) + "," + str(kak) + "," + str(kal) + "," + str(kam) + "," +  str(kan) + "," + str(kao) + "," + str(kap) + "," + str(kaq) + "," + str(kar) + "," + str(kas) + "," + str(kat) + "," + str(kau) + "," + str(kav) + "," + str(kaw) + "," + str(kax)
    file.write(allMessages)
    file.close()

window0 = Window(app, title="WJ-List of Rearrangement", bg="#d2d2d2", width=1890, height=400, layout="grid")
message2 = Text(window0, text="", size=8, grid=[0,0])
message1 = Text(window0, text="", size=8, font="monospace", color="#000000", grid=[0,1])
message2 = Text(window0, text="", size=8, grid=[1,0])
message2C = Text(window0, text="", size=8, font="monospace", color="#000000", grid=[1,1])
message2 = Text(window0, text="", size=8, grid=[2,0])
message3C = Text(window0, text="", size=8, font="monospace", color="#000000", grid=[2,1])
message2 = Text(window0, text="", size=8, grid=[3,0])
message4C = Text(window0, text="", size=8, font="monospace", color="#000000", grid=[3,1])
message2 = Text(window0, text="", size=8, grid=[4,0])
message5C = Text(window0, text="", size=8, font="monospace", color="#000000", grid=[4,1])
close_window_0()

window1 = Window(app, title="WJ-Directory", bg="#d2d2d2", width=270, height=470, layout="auto")
message2 = Text(window1, text="Current Directory", size=10, font="monospace", color="#000000")
message2 = Text(window1, text="CTRL-C to Copy, CTRL-V to Paste", size=10, font="monospace", color="#000000")
message4 = TextBox(window1, text="", height=960, width=350, multiline=True, scrollbar=True)
message4.bg = "#ffffff"
message4.text_color = "#000000"
close_window_1()

window2 = Window(app, title="WJ-From This Directory", bg="#d2d2d2", width=400, height=80)
message2 = Text(window2, text=" ", size=2)
message2 = Text(window2, text="Working Data File:", size=10)
message2 = Text(window2, text="Include extension", size=8)
text1d1 = TextBox(window2, "WJ_Data_" + ".csv", width=50, height=16)
text1d1.bg = "#ffffff"
text1d1.text_color = "#000000"
close_window_2()

window4 = Window(app, title="WJ-Action Buttons", bg="#d2d2d2", width=200, height=570)
message2 = Text(window4, text=" ", size=8)
save_text = PushButton(window4, command=savas5, text="Save All Rows In Order Written")
save_text.bg = "#c0c0ff"
save_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
updateA_text = PushButton(window4, command=messagesCa, text="Rearrange All Columns & Save Jumble")
updateA_text.bg = "#c0c0ff"
updateA_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
update_text = PushButton(window4, command=messages, text="Rearrange Column 1")
update_text.bg = "#c0c0ff"
update_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
update2_text = PushButton(window4, command=messagesC2, text="Rearrange Column 2")
update2_text.bg = "#c0c0ff"
update2_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
update3_text = PushButton(window4, command=messagesC3, text="Rearrange Column 3")
update3_text.bg = "#c0c0ff"
update3_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
update3_text = PushButton(window4, command=messagesC4, text="Rearrange Column 4")
update3_text.bg = "#c0c0ff"
update3_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
update4_text = PushButton(window4, command=messagesC5, text="Rearrange Column 5")
update4_text.bg = "#c0c0ff"
update4_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
fill_text = PushButton(window4, command=getfiles7, text="Fill From Filename Typed In Directory Box")
fill_text.bg = "#c0c0ff"
fill_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
getThose_files = PushButton(window4, command=getfiles5, text="List Files Of Current Directory")
getThose_files.bg = "#c0c0ff"
getThose_files.text_color = "#000000"
close_window_4()

app.display()
