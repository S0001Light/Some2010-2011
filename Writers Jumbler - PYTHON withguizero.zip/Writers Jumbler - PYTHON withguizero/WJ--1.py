from guizero import App, Window, MenuBar, TextBox, Text, PushButton, Slider
import random
from operator import itemgetter
import os
from os import path
import io
import sys

def file_function():
    ("File option")
def edit_function():
    ("Edit Option")
def open_window_0():
    window0.show()
def close_window_0():
    window0.hide()
def open_window_1():
    window1.show()
def close_window_1():
    window1.hide()
def open_window_2():
    window2.show()
def close_window_2():
    window2.hide()

def open_window_4():
    window4.show()
def close_window_4():
    window4.hide()
def open_window_5():
    window5.show()
def close_window_5():
    window5.hide()
def open_window_6():
    window6.show()
def close_window_6():
    window6.hide()

app = App(title="Writers Jumbler - 1 Column", bg="#d2d2d2", width=500, height=350)
    
window5 = Window(app, title="WJ-Color Background", bg="#d2d2d2", width=400, height=340)
message2 = Text(window5, text="", size=12)

mna = ""
def Change1(mna):
    haaha = (Change1)

mnb = ""
def Change2(mnb):
    haahb = (Change2)

mnc = ""
def Change3(mnc):
    haahc = (Change3)
    
lbl0 = Text(window5, text="", size=2)
message7 = Text(window5, text="RED", size=12)
lbl0 = Text(window5, text="", size=2)
colorSlide1 = Slider(window5, command=Change1, start=0, end=255)
colorSlide1.bg = "#ffffff"
colorSlide1.width = "255"
colorSlide1.value = "255"
lbl0 = Text(window5, text="", size=2)
message8 = Text(window5, text="GREEN", size=12)
lbl0 = Text(window5, text="", size=2)
colorSlide2 = Slider(window5, command=Change2, start=0, end=255)
colorSlide2.bg = "#ffffff"
colorSlide2.width = "255"
colorSlide2.value = "255"
lbl0 = Text(window5, text="", size=2)
message9 = Text(window5, text="BLUE", size=12)
lbl0 = Text(window5, text="", size=2)
colorSlide3 = Slider(window5, command=Change3, start=0, end=255)
colorSlide3.bg = "#ffffff"
colorSlide3.width = "255"
colorSlide3.value = "255"

def colorRGB():
    colorRa = colorSlide1.value
    colorGa = colorSlide2.value
    colorBa = colorSlide3.value
    colorCT = (colorRa, colorGa, colorBa)
    window0.bg = colorCT

lbl0 = Text(window5, text="", size=2)
color_text = PushButton(window5, command=colorRGB, text="Color This Window Background")
color_text.bg = "#c0c0ff"
color_text.text_color = "#000000"

close_window_5()

window6 = Window(app, title="WJ-Color Font", bg="#d2d2d2", width=400, height=340)

message2 = Text(window6, text="", size=12)

mna = ""
def Change4(mna):
    haaha = (Change4)

mnb = ""
def Change5(mnb):
    haahb = (Change5)

mnc = ""
def Change6(mnc):
    haahc = (Change6)

lbl0 = Text(window6, text="", size=2)
message10 = Text(window6, text="RED", size=12)
lbl0 = Text(window6, text="", size=2)
colorSlide4 = Slider(window6, command=Change4, start=0, end=255)
colorSlide4.bg = "#ffffff"
colorSlide4.width = "255"
colorSlide4.value = "0"
lbl0 = Text(window6, text="", size=2)
message11 = Text(window6, text="GREEN", size=12)
lbl0 = Text(window6, text="", size=2)
colorSlide5 = Slider(window6, command=Change5, start=0, end=255)
colorSlide5.bg = "#ffffff"
colorSlide5.width = "255"
colorSlide5.value = "0"
lbl0 = Text(window6, text="", size=2)
message12 = Text(window6, text="BLUE", size=12)
lbl0 = Text(window6, text="", size=2)
colorSlide6 = Slider(window6, command=Change6, start=0, end=255)
colorSlide6.bg = "#ffffff"
colorSlide6.width = "255"
colorSlide6.value = "0"

def colorCFT():
    colorRf2 = colorSlide4.value
    colorGf2 = colorSlide5.value
    colorBf2 = colorSlide6.value
    colorCTf = (colorRf2, colorGf2, colorBf2)
    window0.text_color = colorCTf

message2 = Text(window6, text="", size=8)
color_text = PushButton(window6, command=colorCFT, text="Color Fonts")
color_text.bg = "#c0c0ff"
color_text.text_color = "#000000"
close_window_6()

def savas1():
    aValue = text1.value
    bValue = text2.value
    cValue = text3.value
    dValue = text4.value
    eValue = text5.value
    fValue = text6.value
    gValue = text7.value
    hValue = text8.value
    iValue = text9.value
    jValue = text10.value

    word = "WJ1_inOrder_1c_"
    i = random.randint(0, 1000000)
    z = word + str(i) + ".csv"

    file = open(z, "w")

    allMessages = str(aValue) +  "," +  str(bValue) +  "," +  str(cValue) +  "," +  str(dValue) +  "," +  str(eValue) +  "," +  str(fValue) +  "," +  str(gValue) +  "," +  str(hValue) +  "," +  str(iValue) +  "," +  str(jValue)
    file.write(allMessages)
    file.close()

def getfiles7():
    list_a = []
    list_b = []
    list_c = []
    list_d = []
    list_e = []
    list_f = []
    list_g = []
    list_h = []
    list_i = []
    list_j = []
    ab = text11.value
    with open(ab, "r") as t:
        for line in t:
            words = line.split(",")
            word_1 = words[0]
            word_2 = words[1]
            word_3 = words[2]
            word_4 = words[3]
            word_5 = words[4]
            word_6 = words[5]
            word_7 = words[6]
            word_8 = words[7]
            word_9 = words[8]
            word_10 = words[9]
            text1.value = word_1
            text2.value = word_2
            text3.value = word_3
            text4.value = word_4
            text5.value = word_5
            text6.value = word_6
            text7.value = word_7
            text8.value = word_8
            text9.value = word_9
            text10.value = word_10

def getfiles5():
    files = []
    files = os.listdir(os.getcwd())
    files = "".join(repr(files).replace(",", "\n").replace("[", "").replace("]", "").replace("'", ""))
    message4.value = files

exitWindow = exit

file_Menu = MenuBar(app, toplevel=["File", "Options"], options=[ [ ["Save, with Random File Name", savas1], ["Open Directory Box", open_window_2], ["Open Directory Window", open_window_1], ["List Files In WJ-Directory", getfiles5], ["Fill, From File", getfiles7], ["Exit, Writers Jumbler", exitWindow] ], [ ["Open Rearrangements", open_window_0], ["Open Color Background", open_window_5], ["Open Color Font", open_window_6], ["Open Action Buttons", open_window_4]],])
message2 = Text(app, text="", size=20)
text1 = TextBox(app, width=50, height=16)
text1.bg = "#ffffff"
message2 = Text(app, text=" ", size=2)
text2 = TextBox(app, width=50, height=16)
text2.bg = "#ffffff"
message2 = Text(app, text=" ", size=2)
text3 = TextBox(app, width=50, height=16)
text3.bg = "#ffffff"
message2 = Text(app, text=" ", size=2)
text4 = TextBox(app, width=50, height=16)
text4.bg = "#ffffff"
text2.bg = "#ffffff"
message2 = Text(app, text=" ", size=2)
text5 = TextBox(app, width=50, height=16)
text5.bg = "#ffffff"
message2 = Text(app, text=" ", size=2)
text6 = TextBox(app, width=50, height=16)
text6.bg = "#ffffff"
message2 = Text(app, text=" ", size=2)
text7 = TextBox(app, width=50, height=16)
text7.bg = "#ffffff"
message2 = Text(app, text=" ", size=2)
text8 = TextBox(app, width=50, height=16)
text8.bg = "#ffffff"
message2 = Text(app, text=" ", size=2)
text9 = TextBox(app, width=50, height=16)
text9.bg = "#ffffff"
message2 = Text(app, text=" ", size=2)
text10 = TextBox(app, width=50, height=16)
text10.bg = "#ffffff"
message2 = Text(app, text=" ", size=2)

def messages():
    value1 = str(random.randint(0, 9))
    value2 = str(random.randint(0, 9))
    value3 = str(random.randint(0, 9))
    value4 = str(random.randint(0, 9))
    value5 = str(random.randint(0, 9))
    value6 = str(random.randint(0, 9))
    value7 = str(random.randint(0, 9))
    value8 = str(random.randint(0, 9))
    value9 = str(random.randint(0, 9))
    value10 = str(random.randint(0, 9))

    aValue = text1.value
    bValue = text2.value
    cValue = text3.value
    dValue = text4.value
    eValue = text5.value
    fValue = text6.value
    gValue = text7.value
    hValue = text8.value
    iValue = text9.value
    jValue = text10.value

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]

    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    ka = [xa]
    kb = [xb]
    kc = [xc]
    kd = [xd]
    ke = [xe]
    kf = [xf]
    kg = [xg]
    kh = [xh]
    ki = [xi]
    kj = [xj]

    xxxx = (ka, kb, kc, kd, ke, kf, kg, kh, ki, kj)

    xxxxx0 = "".join(repr(xxxx).replace("{","").replace("}","").replace(",", "").replace("'", "\n").replace("[", "").replace("]", "").replace("(", "").replace(")", "").replace("]", ""))
    message1.value = xxxxx0

    word = "WJ1_Jumble_Save_1c_"
    i = random.randint(0, 1000000)
    z = word + str(i) + ".csv"

    file = open(z, "w")

    allMessages = str(ka) +  "," +  str(kb) +  "," +  str(kc) +  "," +  str(kd) +  "," +  str(ke) +  "," +  str(kf) +  "," +  str(kg) +  "," +  str(kh) +  "," +  str(ki) +  "," +  str(kj)
    file.write(allMessages)
    file.close()

window0 = Window(app, title="WJ-Rearrangements", bg="#d2d2d2", width=500, height=400)
message2 = Text(window0, text="", size=8)
message1 = Text(window0, text="", size=8, font="monospace", color="#000000")
close_window_0()

window1 = Window(app, title="WJ-Directory", bg="#d2d2d2", width=270, height=470)
message2 = Text(window1, text="Current Directory", size=10, font="monospace", color="#000000")
message2 = Text(window1, text="CTRL-C to Copy, CTRL-V to Paste", size=10, font="monospace", color="#000000")
message4 = TextBox(window1, text="", height=960, width=350, multiline=True, scrollbar=True)
message4.bg = "#ffffff"
message4.text_color = "#000000"
close_window_1()

window2 = Window(app, title="WJ-From This Directory", bg="#d2d2d2", width=400, height=80)
message2 = Text(window2, text=" ", size=2)
message2 = Text(window2, text="Working Data File:", size=10)
message2 = Text(window2, text="Include extension", size=8)
text11 = TextBox(window2, "WJ_Data_File_Name_Here" + ".csv", width=50, height=16)
text11.bg = "#ffffff"
text11.text_color = "#000000"
close_window_2()

window4 = Window(app, title="WJ-Action Buttons", bg="#d2d2d2", width=200, height=264)
message2 = Text(window4, text=" ", size=8)
save_text = PushButton(window4, command=savas1, text="Save All Rows In Order Written")
save_text.bg = "#c0c0ff"
save_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
update_text = PushButton(window4, command=messages, text="Rearrange, All Rows & Save Jumble")
update_text.bg = "#c0c0ff"
update_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
fill_text = PushButton(window4, command=getfiles7, text="Fill From Filename Typed In Directory Box")
fill_text.bg = "#c0c0ff"
fill_text.text_color = "#000000"
message2 = Text(window4, text=" ", size=8)
getThose_files = PushButton(window4, command=getfiles5, text="List Files Of Current Directory")
getThose_files.bg = "#c0c0ff"
getThose_files.text_color = "#000000"
close_window_4()

app.display()
