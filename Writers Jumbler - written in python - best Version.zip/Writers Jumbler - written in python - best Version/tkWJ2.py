from tkinter import *
import random
from operator import itemgetter
import os
from os import path
import io
import sys
import datetime

def open_window_0():
    if (window0 is not None) and window0.winfo_exists():
        window0.withdraw()
        window0.deiconify()
    else:
        wjWindow0()
    return
def open_window_1():
    if (window3 is not None) and window1.winfo_exists():
        window1.withdraw()
        window1.deiconify()
    else:
        wjWindow1()
    return
def open_window_2():
    if (window2 is not None) and window2.winfo_exists():
        window2.withdraw()
        window2.deiconify()
    else:
        wjWindow2()
    return
def open_window_3():
    if (window3 is not None) and window3.winfo_exists():
        window3.withdraw()
        window3.deiconify()
    else:
        wjWindow3()
    return
def open_window_4():
    if (window4 is not None) and window4.winfo_exists():
        window4.withdraw()
        window4.deiconify()
    else:
        wjWindow4()
    return
def open_window_5():
    if (window5 is not None) and window5.winfo_exists():
        window5.withdraw()
        window5.deiconify()
    else:
        wjWindow5()
    return
    
app = Tk()
app.title(string="Writers Jumbler")
    
def wjWindow0():
    global window0
    
    window0 = Toplevel(app)
    window0.title(string="Color Background")
    window0.geometry("240x220")
    message2 = Label(window0, text=" ").pack()
    
    var1 = DoubleVar()
    var2 = DoubleVar()
    var3 = DoubleVar()

    colorSlide1 = Scale(window0, label="RED", orient=HORIZONTAL, from_=0, to=255, variable=var1)
    colorSlide1.pack()
    colorSlide2 = Scale(window0, label="GREEN", orient=HORIZONTAL, from_=0, to=255, variable=var2)
    colorSlide2.pack()
    colorSlide3 = Scale(window0, label="BLUE", orient=HORIZONTAL, from_=0, to=255, variable=var3)
    colorSlide3.pack()

    def colorRGB():
        colorRa = int(var1.get())
        colorGa = int(var2.get())
        colorBa = int(var3.get())
        colorAa = "{:#04x}"
        colorRb = int(hex(colorRa), 16)
        colorGb = int(hex(colorGa), 16)
        colorBb = int(hex(colorBa), 16)
        colorRab = colorAa.format(colorRb)
        colorGab = colorAa.format(colorGb)
        colorBab = colorAa.format(colorBb)
        colorRc = "".join(repr(colorRab).replace("0x", "").replace("'", ""))
        colorGc = "".join(repr(colorGab).replace("0x", "").replace("'", ""))
        colorBc = "".join(repr(colorBab).replace("0x", "").replace("'", ""))
        colorRd = colorRc
        colorGd = colorGc
        colorBd = colorBc
        colorCTa = (colorRd, colorGd, colorBd)
        colorCTb = "".join(repr(colorCTa).replace(",", "").replace("('", "").replace("' '", "").replace("')", ""))
        colorCTc = "#" + colorCTb
        window2.config(bg=colorCTc)
        message1.config(bg=colorCTc)
        message2z.config(bg=colorCTc)
        return

    color_text = Button(window0, command=colorRGB, text="Color This Window Background").pack()
    return

wj0 = wjWindow0()
window0.withdraw()

def wjWindow1():
    global window1
    
    window1 = Toplevel(app)
    window1.title(string="Color Font")
    window1.geometry("240x220")
    message2 = Label(window1, text=" ").pack()
    
    var4 = DoubleVar()
    var5 = DoubleVar()
    var6 = DoubleVar()

    colorSlide4 = Scale(window1, label="RED", orient=HORIZONTAL, from_=0, to=255, variable=var4)
    colorSlide4.pack()
    colorSlide5 = Scale(window1, label="GREEN", orient=HORIZONTAL, from_=0, to=255, variable=var5)
    colorSlide5.pack()
    colorSlide6 = Scale(window1, label="BLUE", orient=HORIZONTAL, from_=0, to=255, variable=var6)
    colorSlide6.pack()

    def colorRGB2():
        colorRa = int(var4.get())
        colorGa = int(var5.get())
        colorBa = int(var6.get())
        colorAa = "{:#04x}"
        colorRb = int(hex(colorRa), 16)
        colorGb = int(hex(colorGa), 16)
        colorBb = int(hex(colorBa), 16)
        colorRab = colorAa.format(colorRb)
        colorGab = colorAa.format(colorGb)
        colorBab = colorAa.format(colorBb)
        colorRc = "".join(repr(colorRab).replace("0x", "").replace("'", ""))
        colorGc = "".join(repr(colorGab).replace("0x", "").replace("'", ""))
        colorBc = "".join(repr(colorBab).replace("0x", "").replace("'", ""))
        colorRd = colorRc
        colorGd = colorGc
        colorBd = colorBc
        colorCTa = (colorRd, colorGd, colorBd)
        colorCTb = "".join(repr(colorCTa).replace(",", "").replace("('", "").replace("' '", "").replace("')", ""))
        colorCTc = "#" + colorCTb
        message1.config(fg=colorCTc)
        message2z.config(fg=colorCTc)
        return

    color_text = Button(window1, command=colorRGB2, text="Color Fonts").pack()
    return

wj1 = wjWindow1()
window1.withdraw()

def savas2():
    aValue = text1.get()
    bValue = text2.get()
    cValue = text3.get()
    dValue = text4.get()
    eValue = text5.get()
    fValue = text6.get()
    gValue = text7.get()
    hValue = text8.get()
    iValue = text9.get()
    jValue = text10.get()
    kValue = text11.get()
    lValue = text12.get()
    mValue = text13.get()
    nValue = text14.get()
    oValue = text15.get()
    pValue = text16.get()
    qValue = text17.get()
    rValue = text18.get()
    sValue = text19.get()
    tValue = text20.get()

    word = "WJ2_inOrder_2c_"
    dthm = datetime.datetime.now()
    m = str(dthm.strftime("%m"))
    dy = str(dthm.strftime("%d"))
    y = str(dthm.strftime("%Y"))
    h = str(dthm.strftime("%I"))
    mins = str(dthm.strftime("%M"))
    amPm = str(dthm.strftime("%p"))
    sec = str(dthm.strftime("%S"))
    dash = "-"
    d = str(m + dash + dy + dash + y + dash + h + dash + mins + dash + sec + dash + amPm)
    z = word + d + ".csv"

    file = open(z, "w")

    allMessages = str(aValue) + ";" +  str(bValue) + ";" +  str(cValue) + ";" +  str(dValue) + ";" +  str(eValue) + ";" +  str(fValue) + ";" +  str(gValue) + ";" +  str(hValue) + ";" +  str(iValue) + ";" +  str(jValue) + ";" +  str(kValue) + ";" +  str(lValue) + ";" + str(mValue) + ";" +  str(nValue) + ";" +  str(oValue) + ";" +  str(pValue) + ";" +  str(qValue) + ";" +  str(rValue) + ";" +  str(sValue) + ";" +  str(tValue)
    file.write(allMessages)
    file.close()
    return

def getfiles7():
    global text11z
    
    list_a = []
    list_b = []
    list_c = []
    list_d = []
    list_e = []
    list_f = []
    list_g = []
    list_h = []
    list_i = []
    list_j = []
    list_k = []
    list_l = []
    list_m = []
    list_n = []
    list_o = []
    list_p = []
    list_q = []
    list_r = []
    list_s = []
    list_t = []
    abz = text11z.get()
    with open(abz, "r") as tz:
        for line in tz:
            words = line.split(";")
            word_1 = words[0]
            word_2 = words[1]
            word_3 = words[2]
            word_4 = words[3]
            word_5 = words[4]
            word_6 = words[5]
            word_7 = words[6]
            word_8 = words[7]
            word_9 = words[8]
            word_10 = words[9]
            word_11 = words[10]
            word_12 = words[11]
            word_13 = words[12]
            word_14 = words[13]
            word_15 = words[14]
            word_16 = words[15]
            word_17 = words[16]
            word_18 = words[17]
            word_19 = words[18]
            word_20 = words[19]
            a.set(word_1)
            b.set(word_2)
            c.set(word_3)
            d.set(word_4)
            e.set(word_5)
            f.set(word_6)
            g.set(word_7)
            h.set(word_8)
            i.set(word_9)
            j.set(word_10)
            k.set(word_11)
            l.set(word_12)
            m.set(word_13)
            n.set(word_14)
            o.set(word_15)
            p.set(word_16)
            q.set(word_17)
            r.set(word_18)
            s.set(word_19)
            t.set(word_20)	
    return

def getfiles5():
    global message4
    
    files = []
    files = os.listdir(os.getcwd())
    files = "".join(repr(files).replace(",", "\n").replace("[", "").replace("]", "").replace("'", "").replace(" ", ""))
    message4.config(state=NORMAL)
    message4.delete(1.0, END)
    message4.insert(END, files + "\n")
    message4.config(state=DISABLED)

exitWindow = exit

menuBar = Frame(app, relief=RAISED, borderwidth=1)
menuBar.grid(row=0, column=0, sticky=W)
FileMenu = Menubutton(menuBar, text="FILE")
FileMenu.grid(row=0, column=0)
FileMenu.menu = Menu(FileMenu)
FileMenu.menu.add_command(label="SAVE, WITH DATE AND TIME", command=savas2)
FileMenu.menu.add_command(label="LIST FILES IN DIRECTORY WINDOW", command=getfiles5)
FileMenu.menu.add_command(label="OPEN, FROM FILE, FROM DIRECTORY INPUT", command=getfiles7)
FileMenu.menu.add_command(label="EXIT, WRITERS JUMBLER", command=exitWindow)
FileMenu['menu'] = FileMenu.menu
OpenMenu = Menubutton(menuBar, text="OPEN")
OpenMenu.grid(row=0, column=1)
OpenMenu.menu = Menu(OpenMenu)
OpenMenu.menu.add_command(label="OPEN REARRANGEMENTS", command=open_window_2)
OpenMenu.menu.add_command(label="OPEN ACTION BUTTONS", command=open_window_5)
OpenMenu.menu.add_command(label="OPEN COLOR BACKGROUND", command=open_window_0)
OpenMenu.menu.add_command(label="OPEN COLOR FONT", command=open_window_1)
OpenMenu.menu.add_command(label="OPEN DIRECTORY WINDOW", command=open_window_3)
OpenMenu.menu.add_command(label="OPEN DIRECTORY INPUT", command=open_window_4)
OpenMenu['menu'] = OpenMenu.menu

a = StringVar()
text1 = Entry(app, textvariable=a, width=75)
text1.grid(row=1, column=0)
b = StringVar()
text2 = Entry(app, textvariable=b, width=75)
text2.grid(row=2, column=0)
c = StringVar()
text3 = Entry(app, textvariable=c, width=75)
text3.grid(row=3, column=0)
d = StringVar()
text4 = Entry(app, textvariable=d, width=75)
text4.grid(row=4, column=0)
e = StringVar()
text5 = Entry(app, textvariable=e, width=75)
text5.grid(row=5, column=0)
f = StringVar()
text6 = Entry(app, textvariable=f, width=75)
text6.grid(row=6, column=0)
g = StringVar()
text7 = Entry(app, textvariable=g, width=75)
text7.grid(row=7, column=0)
h = StringVar()
text8 = Entry(app, textvariable=h, width=75)
text8.grid(row=8, column=0)
i = StringVar()
text9 = Entry(app, textvariable=i, width=75)
text9.grid(row=9, column=0)
j = StringVar()
text10 = Entry(app, textvariable=j, width=75)
text10.grid(row=10, column=0)
k = StringVar()
text11 = Entry(app, textvariable=k, width=75)
text11.grid(row=1, column=1)
l = StringVar()
text12 = Entry(app, textvariable=l, width=75)
text12.grid(row=2, column=1)
m = StringVar()
text13 = Entry(app, textvariable=m, width=75)
text13.grid(row=3, column=1)
n = StringVar()
text14 = Entry(app, textvariable=n, width=75)
text14.grid(row=4, column=1)
o = StringVar()
text15 = Entry(app, textvariable=o, width=75)
text15.grid(row=5, column=1)
p = StringVar()
text16 = Entry(app, textvariable=p, width=75)
text16.grid(row=6, column=1)
q = StringVar()
text17 = Entry(app, textvariable=q, width=75)
text17.grid(row=7, column=1)
r = StringVar()
text18 = Entry(app, textvariable=r, width=75)
text18.grid(row=8, column=1)
s = StringVar()
text19 = Entry(app, textvariable=s, width=75)
text19.grid(row=9, column=1)
t = StringVar()
text20 = Entry(app, textvariable=t, width=75)
text20.grid(row=10, column=1)

def messagesC1():
    value1 = str(random.randint(0, 9))
    value2 = str(random.randint(0, 9))
    value3 = str(random.randint(0, 9))
    value4 = str(random.randint(0, 9))
    value5 = str(random.randint(0, 9))
    value6 = str(random.randint(0, 9))
    value7 = str(random.randint(0, 9))
    value8 = str(random.randint(0, 9))
    value9 = str(random.randint(0, 9))
    value10 = str(random.randint(0, 9))

    aValue = text1.get()
    bValue = text2.get()
    cValue = text3.get()
    dValue = text4.get()
    eValue = text5.get()
    fValue = text6.get()
    gValue = text7.get()
    hValue = text8.get()
    iValue = text9.get()
    jValue = text10.get()

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]

    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    ka = [xa]
    kb = [xb]
    kc = [xc]
    kd = [xd]
    ke = [xe]
    kf = [xf]
    kg = [xg]
    kh = [xh]
    ki = [xi]
    kj = [xj]

    xxxx = (ka, kb, kc, kd, ke, kf, kg, kh, ki, kj)

    xxxxx0 = "".join(repr(xxxx).replace("(['","\n").replace('(["','\n').replace("'], ['", "\n\n").replace('"])', '\n').replace("'])", "\n").replace("'],","\n").replace(" ['","\n").replace('"],','\n').replace(' ["','\n'))
    zzzzz0.set(xxxxx0)
    return

def messagesC2():
    value11 = str(random.randint(0, 9))
    value12 = str(random.randint(0, 9))
    value13 = str(random.randint(0, 9))
    value14 = str(random.randint(0, 9))
    value15 = str(random.randint(0, 9))
    value16 = str(random.randint(0, 9))
    value17 = str(random.randint(0, 9))
    value18 = str(random.randint(0, 9))
    value19 = str(random.randint(0, 9))
    value20 = str(random.randint(0, 9))

    kValue = text11.get()
    lValue = text12.get()
    mValue = text13.get()
    nValue = text14.get()
    oValue = text15.get()
    pValue = text16.get()
    qValue = text17.get()
    rValue = text18.get()
    sValue = text19.get()
    tValue = text20.get()

    za2 = []
    zb2 = []
    zc2 = []
    zd2 = []
    ze2 = []
    zf2 = []
    zg2 = []
    zh2 = []
    zi2 = []
    zj2 = []

    ya2 = [za2, zb2, zc2, zd2, ze2, zf2, zg2, zh2, zi2, zj2]
    za2 = [value11, kValue, '\n']
    zb2 = [value12, lValue, '\n']
    zc2 = [value13, mValue, '\n']
    zd2 = [value14, nValue, '\n']
    ze2 = [value15, oValue, '\n']
    zf2 = [value16, pValue, '\n']
    zg2 = [value17, qValue, '\n']
    zh2 = [value18, rValue, '\n']
    zi2 = [value19, sValue, '\n']
    zj2 = [value20, tValue, '\n']
    ya2 = [za2, zb2, zc2, zd2, ze2, zf2, zg2, zh2, zi2, zj2]

    zzx2 = sorted(ya2, key=itemgetter(0), reverse=False)
    zzz2 = zzx2

    qa2 = zzx2[0]
    qb2 = zzx2[1]
    qc2 = zzx2[2]
    qd2 = zzx2[3]
    qe2 = zzx2[4]
    qf2 = zzx2[5]
    qg2 = zzx2[6]
    qh2 = zzx2[7]
    qi2 = zzx2[8]
    qj2 = zzx2[9]

    xa2 = qa2[-2]
    xb2 = qb2[-2]
    xc2 = qc2[-2]
    xd2 = qd2[-2]
    xe2 = qe2[-2]
    xf2 = qf2[-2]
    xg2 = qg2[-2]
    xh2 = qh2[-2]
    xi2 = qi2[-2]
    xj2 = qj2[-2]

    ka2 = [xa2]
    kb2 = [xb2]
    kc2 = [xc2]
    kd2 = [xd2]
    ke2 = [xe2]
    kf2 = [xf2]
    kg2 = [xg2]
    kh2 = [xh2]
    ki2 = [xi2]
    kj2 = [xj2]

    xxxx2 = (ka2, kb2, kc2, kd2, ke2, kf2, kg2, kh2, ki2, kj2)

    xxxxx1 = "".join(repr(xxxx2).replace("(['","\n").replace('(["','\n').replace("'], ['", "\n\n").replace('"])', '\n').replace("'])", "\n").replace("'],","\n").replace(" ['","\n").replace('"],','\n').replace(' ["','\n'))
    zzzzz1.set(xxxxx1)
    return

def messagesCa():
    value1 = str(random.randint(0, 9))
    value2 = str(random.randint(0, 9))
    value3 = str(random.randint(0, 9))
    value4 = str(random.randint(0, 9))
    value5 = str(random.randint(0, 9))
    value6 = str(random.randint(0, 9))
    value7 = str(random.randint(0, 9))
    value8 = str(random.randint(0, 9))
    value9 = str(random.randint(0, 9))
    value10 = str(random.randint(0, 9))

    aValue = text1.get()
    bValue = text2.get()
    cValue = text3.get()
    dValue = text4.get()
    eValue = text5.get()
    fValue = text6.get()
    gValue = text7.get()
    hValue = text8.get()
    iValue = text9.get()
    jValue = text10.get()

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]

    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    ka = [xa]
    kb = [xb]
    kc = [xc]
    kd = [xd]
    ke = [xe]
    kf = [xf]
    kg = [xg]
    kh = [xh]
    ki = [xi]
    kj = [xj]

    xxxx = (ka, kb, kc, kd, ke, kf, kg, kh, ki, kj)

    xxxxx0 = "".join(repr(xxxx).replace("(['","\n").replace('(["','\n').replace("'], ['", "\n\n").replace('"])', '\n').replace("'])", "\n").replace("'],","\n").replace(" ['","\n").replace('"],','\n').replace(' ["','\n'))
    zzzzz0.set(xxxxx0)

    value11 = str(random.randint(0, 9))
    value12 = str(random.randint(0, 9))
    value13 = str(random.randint(0, 9))
    value14 = str(random.randint(0, 9))
    value15 = str(random.randint(0, 9))
    value16 = str(random.randint(0, 9))
    value17 = str(random.randint(0, 9))
    value18 = str(random.randint(0, 9))
    value19 = str(random.randint(0, 9))
    value20 = str(random.randint(0, 9))

    kValue = text11.get()
    lValue = text12.get()
    mValue = text13.get()
    nValue = text14.get()
    oValue = text15.get()
    pValue = text16.get()
    qValue = text17.get()
    rValue = text18.get()
    sValue = text19.get()
    tValue = text20.get()

    za2 = []
    zb2 = []
    zc2 = []
    zd2 = []
    ze2 = []
    zf2 = []
    zg2 = []
    zh2 = []
    zi2 = []
    zj2 = []

    ya2 = [za2, zb2, zc2, zd2, ze2, zf2, zg2, zh2, zi2, zj2]
    za2 = [value11, kValue, '\n']
    zb2 = [value12, lValue, '\n']
    zc2 = [value13, mValue, '\n']
    zd2 = [value14, nValue, '\n']
    ze2 = [value15, oValue, '\n']
    zf2 = [value16, pValue, '\n']
    zg2 = [value17, qValue, '\n']
    zh2 = [value18, rValue, '\n']
    zi2 = [value19, sValue, '\n']
    zj2 = [value20, tValue, '\n']
    ya2 = [za2, zb2, zc2, zd2, ze2, zf2, zg2, zh2, zi2, zj2]

    zzx2 = sorted(ya2, key=itemgetter(0), reverse=False)
    zzz2 = zzx2

    qa2 = zzx2[0]
    qb2 = zzx2[1]
    qc2 = zzx2[2]
    qd2 = zzx2[3]
    qe2 = zzx2[4]
    qf2 = zzx2[5]
    qg2 = zzx2[6]
    qh2 = zzx2[7]
    qi2 = zzx2[8]
    qj2 = zzx2[9]

    xa2 = qa2[-2]
    xb2 = qb2[-2]
    xc2 = qc2[-2]
    xd2 = qd2[-2]
    xe2 = qe2[-2]
    xf2 = qf2[-2]
    xg2 = qg2[-2]
    xh2 = qh2[-2]
    xi2 = qi2[-2]
    xj2 = qj2[-2]

    ka2 = [xa2]
    kb2 = [xb2]
    kc2 = [xc2]
    kd2 = [xd2]
    ke2 = [xe2]
    kf2 = [xf2]
    kg2 = [xg2]
    kh2 = [xh2]
    ki2 = [xi2]
    kj2 = [xj2]

    xxxx2 = (ka2, kb2, kc2, kd2, ke2, kf2, kg2, kh2, ki2, kj2)

    xxxxx1 = "".join(repr(xxxx2).replace("(['","\n").replace('(["','\n').replace("'], ['", "\n\n").replace('"])', '\n').replace("'])", "\n").replace("'],","\n").replace(" ['","\n").replace('"],','\n').replace(' ["','\n'))
    zzzzz1.set(xxxxx1)
    return
	
def wjWindow2():
    global window2, zzzzz0, zzzzz1, message1, message2z
    
    window2 = Toplevel(app)
    window2.title(string="WJ-Rearrangements")
    window2.geometry("900x280")
    zzzzz0 = StringVar()
    message1 = Label(window2, textvariable=zzzzz0)
    message1.pack(side=LEFT)
    zzzzz1 = StringVar()
    message2z = Label(window2, textvariable=zzzzz1)
    message2z.pack(side=LEFT)
    return

wj2 = wjWindow2()
window2.withdraw()

def wjWindow3():
    global window3, message4
    
    window3 = Toplevel(app)
    window3.title(string="WJ-Directory")
    message2 = Label(window3, text=" ").pack()
    message2 = Label(window3, text="Current Directory").pack()
    message2 = Label(window3, text="CTRL-C to Copy, CTRL-V to Paste").pack()
    message2 = Label(window3, text=" ").pack()
    message4 = Text(window3, height=30, width=45)
    scroll3 = Scrollbar(window3, command=message4.yview)
    message4.configure(yscrollcommand=scroll3.set)
    message4.pack(side=LEFT)
    scroll3.pack(side=RIGHT, fill=Y)
    return

wj3 = wjWindow3()
window3.withdraw()

def wjWindow4():
    global window4, text11z
    
    window4 = Toplevel(app)
    window4.title(string="WJ-From The Directory")
    window4.geometry("240x140")
    message2 = Label(window4, text=" ").pack()
    message2 = Label(window4, text="Working Data File:").pack()
    message2 = Label(window4, text="Include extension").pack()
    message2 = Label(window4, text=" ").pack()
    someFile = StringVar()
    text11z = Entry(window4, textvariable=someFile)
    text11z.config(width=30)
    text11z.pack()
    return

wj4 = wjWindow4()
window4.withdraw()

def wjWindow5():
    global window5
    
    window5 = Toplevel(app)
    window5.title(string="WJ-Action Buttons")
    window5.geometry("200x270")
    message2 = Label(window5, text=" ").pack()
    save_text = Button(window5, command=savas2, text="Save, With Date And Time").pack()
    message2 = Label(window5, text=" ").pack()
    update_text = Button(window5, command=messagesCa, text="Rearrange, All Rows").pack()
    message2 = Label(window5, text=" ").pack()
    update1_text = Button(window5, command=messagesC1, text="Rearrange, Column 1").pack()
    message2 = Label(window5, text=" ").pack()
    update2_text = Button(window5, command=messagesC2, text="Rearrange, Column 2").pack()
    message2 = Label(window5, text=" ").pack()
    fill_text = Button(window5, command=getfiles7, text="Fill All Rows From File").pack()
    message2 = Label(window5, text=" ").pack()
    getThose_files = Button(window5, command=getfiles5, text="List Files Of Current Directory").pack()
    return

wj5 = wjWindow5()
window5.withdraw()

app.mainloop()
