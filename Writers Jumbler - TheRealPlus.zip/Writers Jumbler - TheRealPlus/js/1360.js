function myImg01() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL1").innerHTML = getImg1.sort();
}

function myImg02() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL2").innerHTML = getImg1.sort();
}

function myImg03() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL3").innerHTML = getImg1.sort();
}

function myImg04() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL4").innerHTML = getImg1.sort();
}

function myImg05() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL5").innerHTML = getImg1.sort();
}

function myImg06() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL6").innerHTML = getImg1.sort();
}

function myImg07() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL7").innerHTML = getImg1.sort();
}

function myImg08() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL8").innerHTML = getImg1.sort();
}

function myImg09() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL9").innerHTML = getImg1.sort();
}

function myImg010() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL10").innerHTML = getImg1.sort();
}

function myImg011() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL11").innerHTML = getImg1.sort();
}

function myImg012() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL12").innerHTML = getImg1.sort();
}

function myImg013() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL13").innerHTML = getImg1.sort();
}

function myImg014() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL14").innerHTML = getImg1.sort();
}

function myImg015() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL15").innerHTML = getImg1.sort();
}

function myImg016() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL16").innerHTML = getImg1.sort();
}

function myImg017() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL17").innerHTML = getImg1.sort();
}

function myImg018() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL18").innerHTML = getImg1.sort();
}

function myImg019() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL19").innerHTML = getImg1.sort();
}

function myImg020() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL20").innerHTML = getImg1.sort();
}

function myImg021() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL21").innerHTML = getImg1.sort();
}

function myImg022() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL22").innerHTML = getImg1.sort();
}

function myImg023() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL23").innerHTML = getImg1.sort();
}

function myImg024() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL24").innerHTML = getImg1.sort();
}

function myImg025() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL25").innerHTML = getImg1.sort();
}

function myImg026() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL26").innerHTML = getImg1.sort();
}

function myImg027() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL27").innerHTML = getImg1.sort();
}

function myImg028() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL28").innerHTML = getImg1.sort();
}

function myImg029() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL29").innerHTML = getImg1.sort();
}

function myImg030() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL30").innerHTML = getImg1.sort();
}

function myImg031() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL31").innerHTML = getImg1.sort();
}

function myImg032() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL32").innerHTML = getImg1.sort();
}

function myImg033() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL33").innerHTML = getImg1.sort();
}

function myImg034() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL34").innerHTML = getImg1.sort();
}

function myImg035() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL35").innerHTML = getImg1.sort();
}

function myImg036() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL36").innerHTML = getImg1.sort();
}

function myImg037() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL37").innerHTML = getImg1.sort();
}

function myImg038() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL38").innerHTML = getImg1.sort();
}

function myImg039() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL39").innerHTML = getImg1.sort();
}

function myImg040() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL40").innerHTML = getImg1.sort();
}

function myImg041() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL41").innerHTML = getImg1.sort();
}

function myImg042() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL42").innerHTML = getImg1.sort();
}

function myImg043() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL43").innerHTML = getImg1.sort();
}

function myImg044() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL44").innerHTML = getImg1.sort();
}

function myImg045() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL45").innerHTML = getImg1.sort();
}

function myImg046() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL46").innerHTML = getImg1.sort();
}

function myImg047() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL47").innerHTML = getImg1.sort();
}

function myImg048() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL48").innerHTML = getImg1.sort();
}

function myImg049() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL49").innerHTML = getImg1.sort();
}

function myImg050() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL50").innerHTML = getImg1.sort();
}

function myImg051() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL51").innerHTML = getImg1.sort();
}

function myImg052() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL52").innerHTML = getImg1.sort();
}

function myImg053() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL53").innerHTML = getImg1.sort();
}

function myImg054() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL54").innerHTML = getImg1.sort();
}

function myImg055() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL55").innerHTML = getImg1.sort();
}

function myImg056() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL56").innerHTML = getImg1.sort();
}

function myImg057() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL57").innerHTML = getImg1.sort();
}

function myImg058() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL58").innerHTML = getImg1.sort();
}

function myImg059() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL59").innerHTML = getImg1.sort();
}

function myImg060() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL60").innerHTML = getImg1.sort();
}

function myImg061() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL61").innerHTML = getImg1.sort();
}

function myImg062() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL62").innerHTML = getImg1.sort();
}

function myImg063() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL63").innerHTML = getImg1.sort();
}

function myImg064() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL64").innerHTML = getImg1.sort();
}

function myImg065() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL65").innerHTML = getImg1.sort();
}

function myImg066() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);
var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);
var numRand21 = Math.floor((Math.random() * 10) + 1);
var numRand22 = Math.floor((Math.random() * 10) + 1);
var numRand23 = Math.floor((Math.random() * 10) + 1);
var numRand24 = Math.floor((Math.random() * 10) + 1);
var numRand25 = Math.floor((Math.random() * 10) + 1);
var numRand26 = Math.floor((Math.random() * 10) + 1);
var numRand27 = Math.floor((Math.random() * 10) + 1);
var numRand28 = Math.floor((Math.random() * 10) + 1);
var numRand29 = Math.floor((Math.random() * 10) + 1);
var numRand30 = Math.floor((Math.random() * 10) + 1);
var numRand31 = Math.floor((Math.random() * 10) + 1);
var numRand32 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image10 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand10 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image11 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand11 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image12 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand12 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image13 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand13 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image14 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand14 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image15 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand15 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image16 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand16 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image17 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand17 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image18 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand18 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image19 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand19 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image20 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand20 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image21 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand21 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image22 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand22 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image23 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand23 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image24 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand24 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image25 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand25 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image26 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand26 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image27 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand27 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image28 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand28 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image29 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand29 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image30 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand30 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image31 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand31 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image32 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand32 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';


var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9, image10, image11, image12, image13, image14, image15, image16, image17, image18, image19, image20, image21, image22, image23, image24, image25, image26, image27, image28, image29, image30, image31, image32];
    document.getElementById("ImgL66").innerHTML = getImg1.sort();
}

function aRefresh() {
    location.reload();
}