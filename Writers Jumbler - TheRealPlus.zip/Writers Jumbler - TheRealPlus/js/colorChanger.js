function gw() {
  document.body.style.backgroundColor = "#555555";
  document.body.style.color = "#ffffff";
  }
  function dbw() {
  document.body.style.backgroundColor = "#070033";
  document.body.style.color = "#ffffff";
  }
  function drw() {
  document.body.style.backgroundColor = "#5b000e";
  document.body.style.color = "#ffffff";
  }
  function by() {
  document.body.style.backgroundColor = "#000000";
  document.body.style.color = "#ffff00";
  }
  function py() {
  document.body.style.backgroundColor = "#2e001b";
  document.body.style.color = "#ffff00";
  }
  function blg() {
  document.body.style.backgroundColor = "#000000";
  document.body.style.color = "#00ff00";
  }
  function blb() {
  document.body.style.backgroundColor = "#000000";
  document.body.style.color = "#007dff";
  }
  function gy() {
  document.body.style.backgroundColor = "#555555";
  document.body.style.color = "#ffff00";
  }
  function lgb() {
  document.body.style.backgroundColor = "#b4b4b4";
  document.body.style.color = "#000000";
  }
  
  function showmenu(elmnt) {
  document.getElementById(elmnt).style.visibility="visible";
  }
  function hidemenu(elmnt) {
  document.getElementById(elmnt).style.visibility="hidden";
  }