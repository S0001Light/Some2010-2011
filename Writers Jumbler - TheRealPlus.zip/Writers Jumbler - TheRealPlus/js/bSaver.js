function setThis() {
	var value1 = document.getElementById("az1").value;
	var value2 = document.getElementById("bz1").value;
	var value3 = document.getElementById("cz1").value;
	var value4 = document.getElementById("dz1").value;
	var value5 = document.getElementById("ez1").value;
	var value6 = document.getElementById("fz1").value;
	var value7 = document.getElementById("gz1").value;
	var value8 = document.getElementById("hz1").value;
	var value9 = document.getElementById("iz1").value;
	var value10 = document.getElementById("jz1").value;
	
	var value11 = document.getElementById("kz1").value;
	var value12 = document.getElementById("lz1").value;
	var value13 = document.getElementById("mz1").value;
	var value14 = document.getElementById("nz1").value;
	var value15 = document.getElementById("oz1").value;
	var value16 = document.getElementById("pz1").value;
	var value17 = document.getElementById("qz1").value;
	var value18 = document.getElementById("rz1").value;
	var value19 = document.getElementById("sz1").value;
	var value20 = document.getElementById("tz1").value;
	
	localStorage.setItem('data11', value1);
	localStorage.setItem('data12', value2);
	localStorage.setItem('data13', value3);
	localStorage.setItem('data14', value4);
	localStorage.setItem('data15', value5);
	localStorage.setItem('data16', value6);
	localStorage.setItem('data17', value7);
	localStorage.setItem('data18', value8);
	localStorage.setItem('data19', value9);
	localStorage.setItem('data20', value10);
	
	localStorage.setItem('data21', value11);
	localStorage.setItem('data22', value12);
	localStorage.setItem('data23', value13);
	localStorage.setItem('data24', value14);
	localStorage.setItem('data25', value15);
	localStorage.setItem('data26', value16);
	localStorage.setItem('data27', value17);
	localStorage.setItem('data28', value18);
	localStorage.setItem('data29', value19);
	localStorage.setItem('data30', value20);
	
	alert("Your writings have been saved locally.");
}

function getThis() {
	
	var a1 = localStorage.getItem('data11');
	var b1 = localStorage.getItem('data12');
	var c1 = localStorage.getItem('data13');
    var d1 = localStorage.getItem('data14');
	var e1 = localStorage.getItem('data15');
	var f1 = localStorage.getItem('data16');
	var g1 = localStorage.getItem('data17');
	var h1 = localStorage.getItem('data18');
	var i1 = localStorage.getItem('data19');
	var j1 = localStorage.getItem('data20');
	
	var k1 = localStorage.getItem('data21');
	var l1 = localStorage.getItem('data22');
	var m1 = localStorage.getItem('data23');
    var n1 = localStorage.getItem('data24');
	var o1 = localStorage.getItem('data25');
	var p1 = localStorage.getItem('data26');
	var q1 = localStorage.getItem('data27');
	var r1 = localStorage.getItem('data28');
	var s1 = localStorage.getItem('data29');
	var t1 = localStorage.getItem('data30');
	
	document.getElementById("az1").defaultValue = a1;
	document.getElementById("bz1").defaultValue = b1;
	document.getElementById("cz1").defaultValue = c1;
	document.getElementById("dz1").defaultValue = d1;
	document.getElementById("ez1").defaultValue = e1;
	document.getElementById("fz1").defaultValue = f1;
	document.getElementById("gz1").defaultValue = g1;
	document.getElementById("hz1").defaultValue = h1;
	document.getElementById("iz1").defaultValue = i1;
	document.getElementById("jz1").defaultValue = j1;
	
	document.getElementById("kz1").defaultValue = k1;
	document.getElementById("lz1").defaultValue = l1;
	document.getElementById("mz1").defaultValue = m1;
	document.getElementById("nz1").defaultValue = n1;
	document.getElementById("oz1").defaultValue = o1;
	document.getElementById("pz1").defaultValue = p1;
	document.getElementById("qz1").defaultValue = q1;
	document.getElementById("rz1").defaultValue = r1;
	document.getElementById("sz1").defaultValue = s1;
	document.getElementById("tz1").defaultValue = t1;
	
}