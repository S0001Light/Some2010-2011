function myRap01() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);
var numRand10 = Math.floor((Math.random() * 10) + 1);

var linewrp1 = document.getElementById("az1").value;
var linewrp2 = document.getElementById("bz1").value;
var linewrp3 = document.getElementById("cz1").value;
var linewrp4 = document.getElementById("dz1").value;
var linewrp5 = document.getElementById("ez1").value;
var linewrp6 = document.getElementById("fz1").value;
var linewrp7 = document.getElementById("gz1").value;
var linewrp8 = document.getElementById("hz1").value;
var linewrp9 = document.getElementById("iz1").value;
var linewrp10 = document.getElementById("jz1").value;

var rap1 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand1 + '</p>' + '<p style="padding-left:10px;">' + linewrp1 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap2 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand2 + '</p>' + '<p style="padding-left:10px;">' + linewrp2 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap3 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand3 + '</p>' + '<p style="padding-left:10px;">' + linewrp3 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap4 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand4 + '</p>' + '<p style="padding-left:10px;">' + linewrp4 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap5 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand5 + '</p>' + '<p style="padding-left:10px;">' + linewrp5 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap6 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand6 + '</p>' + '<p style="padding-left:10px;">' + linewrp6 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap7 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand7 + '</p>' + '<p style="padding-left:10px;">' + linewrp7 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap8 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand8 + '</p>' + '<p style="padding-left:10px;">' + linewrp8 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap9 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand9 + '</p>' + '<p style="padding-left:10px;">' + linewrp9 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap10 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand10 + '</p>' + '<p style="padding-left:10px;">' + linewrp10 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap01 = [rap1, rap2, rap3, rap4, rap5, rap6, rap7, rap8, rap9, rap10];
    document.getElementById("Rap01").innerHTML = getRap01.sort();
}

function myRap02() {

var numRand11 = Math.floor((Math.random() * 10) + 1);
var numRand12 = Math.floor((Math.random() * 10) + 1);
var numRand13 = Math.floor((Math.random() * 10) + 1);
var numRand14 = Math.floor((Math.random() * 10) + 1);
var numRand15 = Math.floor((Math.random() * 10) + 1);
var numRand16 = Math.floor((Math.random() * 10) + 1);
var numRand17 = Math.floor((Math.random() * 10) + 1);
var numRand18 = Math.floor((Math.random() * 10) + 1);
var numRand19 = Math.floor((Math.random() * 10) + 1);
var numRand20 = Math.floor((Math.random() * 10) + 1);

var linewrp11 = document.getElementById("kz1").value;
var linewrp12 = document.getElementById("lz1").value;
var linewrp13 = document.getElementById("mz1").value;
var linewrp14 = document.getElementById("nz1").value;
var linewrp15 = document.getElementById("oz1").value;
var linewrp16 = document.getElementById("pz1").value;
var linewrp17 = document.getElementById("qz1").value;
var linewrp18 = document.getElementById("rz1").value;
var linewrp19 = document.getElementById("sz1").value;
var linewrp20 = document.getElementById("tz1").value;

var rap11 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand11 + '</p>' + '<p style="padding-left:10px;">' + linewrp11 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap12 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand12 + '</p>' + '<p style="padding-left:10px;">' + linewrp12 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap13 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand13 + '</p>' + '<p style="padding-left:10px;">' + linewrp13 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap14 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand14 + '</p>' + '<p style="padding-left:10px;">' + linewrp14 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap15 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand15 + '</p>' + '<p style="padding-left:10px;">' + linewrp15 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap16 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand16 + '</p>' + '<p style="padding-left:10px;">' + linewrp16 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap17 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand17 + '</p>' + '<p style="padding-left:10px;">' + linewrp17 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap18 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand18 + '</p>' + '<p style="padding-left:10px;">' + linewrp18 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap19 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand19 + '</p>' + '<p style="padding-left:10px;">' + linewrp19 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';
var rap20 = '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">' + numRand20 + '</p>' + '<p style="padding-left:10px;">' + linewrp20 + '</p>' + '<p style="visibility:hidden;margin:-15px 0px;">';

var getRap02 = [rap11, rap12, rap13, rap14, rap15, rap16, rap17, rap18, rap19, rap20];
    document.getElementById("Rap02").innerHTML = getRap02.sort();
}